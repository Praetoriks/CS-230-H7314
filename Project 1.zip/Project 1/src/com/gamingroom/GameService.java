package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 * @Name Joshua Perez
 * @Course CS-230-H7314
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game, player, and team identifier
	 * 
	 */
	private static long nextGameId = 1;
	private static long nextPlayerId = 1;
	private static long nextTeamId = 1;


	// private constructor, so that the class cannot be instantiated.
	private static GameService service;
	private GameService(){}
	
	/**
	 * Return reference to Game Service
	 * If the reference exists and is set, return reference
	 * If no reference exists, create a new Game Service & return
	 * This will make it so only one instance exists
	 */
	public static GameService getInstance() {
		if (service == null) {
			service = new GameService();
			System.out.println("Game service created.");
		} else {
			System.out.println("Game service is instantiated already.");
		}
		
		return service;
	}


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		/**
		 *  Use iterator to look for existing game with same name
		 *	if found, simply return the existing instance
		 *	Implementing iterator to traverse the data structure 
		 */
		
		Iterator<Game> gamesIterator = games.iterator();
		
		/**	
		 * 	Searches gamesIterator while it exists
		 *	game variable becomes equal to the next one on the list 
		 *	checks to see if the next variable has the same name as an existing game 
		 */
		while (gamesIterator.hasNext()) {
			Game gameInstance = gamesIterator.next();
			
		// If it exists, exit loop and return existing game	
			if (gameInstance.getName().equalsIgnoreCase(name)) {
				return gameInstance;
			}
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 
	Game getGame(int index) {
		return games.get(index);
	}
	*/
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

	/**
	 *	Use iterator to look for existing game with same id
	 *	if found, simply assign that instance to the local variable
	 */
		Iterator<Game> gamesIterator = games.iterator();
		
	/**
	 *  While iterator is looping, set the game variable with the next one in the iterator
	 *  Check for matching ID
	 *  If ID matches, return existing game, else return null	
	 */
		while(gamesIterator.hasNext() ) {
			Game gameInstance = gamesIterator.next();
			if(gameInstance.getId() == id) {
				return gameInstance;
			}	
		}
		
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		/**
		 *  Use iterator to look for existing game with same name
		 *  if found, return existing game
		 *  else return null
		 */
		Iterator<Game> gamesIterator = games.iterator();
		
		while (gamesIterator.hasNext()) {
			Game gameInstance = gamesIterator.next();
			if(gameInstance.getName().equalsIgnoreCase(name))
				game = gameInstance;
		}
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	/**
	 * Return the next player id
	 * @return player id
	 */
	public long getNextPlayerId() {
		return nextPlayerId;
	}
	
	/**
	 * Return the next team id
	 * @return team id
	 */
	public long getNextTeamId() {
		return nextTeamId;
	}

}
