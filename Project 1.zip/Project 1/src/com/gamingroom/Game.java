package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 * @Name Joshua Perez
 * @Course CS-230-H7314
 */
public class Game extends Entity {
	// long id;
	// String name;
	
	private static List<Team> teams = new ArrayList<Team>();
	

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		super(id, name); // current method
	//	this.id = id;
	//	this.name = name;
	}
	
	public Team addTeam(String name) {
		// Team instance
		Team team = null;
		
		// Instance iterator
		Iterator<Team> teamsIterator = teams.iterator();
		
		// Iterate over teams list
		while (teamsIterator.hasNext()) {
			Team teamInstance = teamsIterator.next();
			
			if (teamInstance.getName().equalsIgnoreCase(name)) {
				team = teamInstance;
			} else {
				teams.add(team);
			}
			
		}
		return team;
	}
	
	/*

	public long getId() {
		return id;
	}


	public String getName() {
		return name;
	}
	*/

	@Override
	public String toString() {
		
		return "Game [id=" + super.getId() + ", name=" + super.getName() + "]";
	}

}
